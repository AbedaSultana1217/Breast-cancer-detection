"""
Gradio scaffold to start from a shared gradio.live link.

This scaffold:
- attempts to download the webpage at the provided URL and save it as downloaded_page.html
- provides a minimal Gradio UI (text input -> echo) as a placeholder until you replace with your real app logic.

Usage:
  1. Edit the variable `REMOTE_URL` below to your gradio.live share link.
  2. Run: python app.py
  3. Visit http://localhost:7860 to see the Gradio UI.

Note: If the original app code is not available on the server behind the share link,
you cannot recover the exact Python source from the URL. This scaffold helps
you recreate a local project that you can push to GitHub and then adapt.
"""
import gradio as gr
import requests
import sys

REMOTE_URL = "https://98e0d745647489b057.gradio.live"

def fetch_remote_page():
    try:
        r = requests.get(REMOTE_URL, timeout=10)
        r.raise_for_status()
        with open("downloaded_page.html", "w", encoding="utf-8") as f:
            f.write(r.text)
        return "Saved downloaded_page.html (fetched remote HTML)."
    except Exception as e:
        return f"Could not fetch remote page: {e}"

def echo(text):
    return "You wrote: " + text

with gr.Blocks() as demo:
    gr.Markdown("# Gradio scaffold
This is a placeholder app. Edit app.py to add your real functionality.")
    with gr.Row():
        inp = gr.Textbox(label="Type something")
        out = gr.Textbox(label="Output")
    btn = gr.Button("Run")
    btn.click(echo, inp, out)
    gr.Button("Fetch remote page").click(lambda: fetch_remote_page(), outputs=[])

if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == "--fetch":
        print(fetch_remote_page())
    else:
        demo.launch(server_name='0.0.0.0', server_port=7860, share=False)

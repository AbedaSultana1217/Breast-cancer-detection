# Gradio App Scaffold

This repository is a starting scaffold to recreate a Gradio project from a shared link.

Original shared URL: https://98e0d745647489b057.gradio.live

## What this scaffold contains
- `app.py` — a minimal Gradio app and a small helper that tries to download the remote page HTML.
- `requirements.txt` — Python dependencies.
- `.gitignore`
- `README.md` — this file.

## How to use
1. Install Python 3.8+ and create a virtual environment:
   ```
   python -m venv venv
   source venv/bin/activate   # Linux / macOS
   venv\Scripts\activate    # Windows
   pip install -r requirements.txt
   ```

2. Run the app locally:
   ```
   python app.py
   ```
   Open http://localhost:7860

3. If you want to attempt to save the remote page HTML to `downloaded_page.html`:
   ```
   python app.py --fetch
   ```

## Push to GitHub
1. Initialize git:
   ```
   git init
   git add .
   git commit -m "Initial scaffold for Gradio app"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<your-repo>.git
   git push -u origin main
   ```

## Important notes
- A gradio.live share link exposes a running app but does not expose the original Python source code. If you need the exact source, ask the owner for the repo or the script.
- Use this scaffold to recreate or reimplement the functionality locally, then push the code to your GitHub repo.
